
  # Creare mockup pagina principala

  This is a code bundle for Creare mockup pagina principala. The original project is available at https://www.figma.com/design/ouhD1zug3SJ42l8JQlHd3f/Creare-mockup-pagina-principala.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  