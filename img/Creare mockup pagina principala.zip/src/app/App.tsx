import { useState, useEffect, useRef } from "react";
import { Compass, Menu, X, BookOpen, MapPin, Mail, Phone, Instagram, Facebook, Youtube, ArrowUp, ChevronLeft, ChevronRight, Star, Clock, Tag, Send, User, MessageSquare, ExternalLink } from "lucide-react";

type Page = "home" | "destinations" | "articles" | "about" | "gear" | "contact";

const TEAL = "#00897B";
const CORAL = "#FF7043";

const IMG = {
  hero1: "https://images.unsplash.com/photo-1614597396930-cd6760b99f7c?w=1400&h=700&fit=crop&auto=format",
  hero2: "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=1400&h=700&fit=crop&auto=format",
  hero3: "https://images.unsplash.com/photo-1771945484043-3a17fbf57a4b?w=1400&h=700&fit=crop&auto=format",
  welcomeImg: "https://images.unsplash.com/photo-1682685797229-b2930538da47?w=700&h=550&fit=crop&auto=format",
  dest1: "https://images.unsplash.com/photo-1771945484043-3a17fbf57a4b?w=600&h=400&fit=crop&auto=format",
  dest2: "https://images.unsplash.com/photo-1626948688703-0136bc0a90da?w=600&h=400&fit=crop&auto=format",
  dest3: "https://images.unsplash.com/photo-1488415032361-b7e238421f1b?w=600&h=400&fit=crop&auto=format",
  dest4: "https://images.unsplash.com/photo-1515784638688-3f7e90ebb446?w=600&h=400&fit=crop&auto=format",
  dest5: "https://images.unsplash.com/photo-1668428202528-bf3d5ed88560?w=600&h=400&fit=crop&auto=format",
  dest6: "https://images.unsplash.com/photo-1504858700536-882c978a3464?w=600&h=400&fit=crop&auto=format",
  art1: "https://images.unsplash.com/photo-1506482379413-b8443e9d9d67?w=600&h=380&fit=crop&auto=format",
  art2: "https://images.unsplash.com/photo-1562593028-1fe2d15bde36?w=600&h=380&fit=crop&auto=format",
  art3: "https://images.unsplash.com/photo-1510158105534-9b01f2462ce1?w=600&h=380&fit=crop&auto=format",
  art4: "https://images.unsplash.com/photo-1682610683618-ca9bc54b0d6e?w=600&h=380&fit=crop&auto=format",
  art5: "https://images.unsplash.com/photo-1488415032361-b7e238421f1b?w=600&h=380&fit=crop&auto=format",
  art6: "https://images.unsplash.com/photo-1668428277573-118ee83608c4?w=600&h=380&fit=crop&auto=format",
  aboutHero: "https://images.unsplash.com/photo-1704610077766-7a5e0535638c?w=800&h=600&fit=crop&auto=format",
  aboutPortrait: "https://images.unsplash.com/photo-1621531518034-94ecf4778186?w=500&h=600&fit=crop&auto=format",
  gear1: "https://images.unsplash.com/photo-1682610683618-ca9bc54b0d6e?w=600&h=400&fit=crop&auto=format",
  gear2: "https://images.unsplash.com/photo-1562593028-1fe2d15bde36?w=600&h=400&fit=crop&auto=format",
  gear3: "https://images.unsplash.com/photo-1634040843188-5ca36cf26cc1?w=600&h=400&fit=crop&auto=format",
  gear4: "https://images.unsplash.com/photo-1704610077766-7a5e0535638c?w=600&h=400&fit=crop&auto=format",
};

const destinations = [
  { id: 1, name: "Insulele Maldive", country: "Maldive", category: "Plaje", img: IMG.dest1, rating: 4.9, days: "7–14 zile", desc: "Atoluri de corali, bungalouri pe apă și un cer înstelat de vis. Paradisul absolut pentru cei care caută liniștea oceanului." },
  { id: 2, name: "Munții Carpați", country: "România", category: "Trekking", img: IMG.dest2, rating: 4.7, days: "3–7 zile", desc: "Trasee alpine spectaculoase, flori de colț și sate tradiționale. Carpații sunt bijuteria ascunsă a Europei de Est." },
  { id: 3, name: "Aurora Boreală", country: "Islanda", category: "Natură", img: IMG.dest3, rating: 5.0, days: "5–10 zile", desc: "Dans de lumini verzi și violet pe cerul nordic. O experiență care schimbă modul în care privești planeta noastră." },
  { id: 4, name: "Santorini", country: "Grecia", category: "Cultura", img: IMG.dest4, rating: 4.8, days: "4–7 zile", desc: "Faleaze albe, cupole albastre și apusuri de soare care par pictate. Insula iubirii cu savori culinare autentice." },
  { id: 5, name: "Grand Place", country: "Belgia", category: "Urban", img: IMG.dest5, rating: 4.6, days: "2–4 zile", desc: "Piețe baroce, ciocolată belgiană și o vibrație urbană cosmopolită ce amestecă istoria cu modernitatea." },
  { id: 6, name: "Fiorduri Nordice", country: "Islanda", category: "Aventură", img: IMG.dest6, rating: 4.8, days: "7–12 zile", desc: "Cascade gigantice, gheizere și câmpuri de lavă. Islanda este planeta noastră la puterea a doua." },
];

const articles = [
  { id: 1, title: "10 Locuri Ascunse în Carpații Românești", category: "Trekking", date: "12 Mai 2026", readTime: "8 min", img: IMG.art1, excerpt: "Dincolo de traseele bătătorite, Carpații ascund lacuri glaciare, cabane retrase și poteci secrete cunoscute doar de localnici." },
  { id: 2, title: "Ghid Complet: Bali în 14 Zile", category: "Asia", date: "3 Mai 2026", readTime: "12 min", img: IMG.art2, excerpt: "De la terasele de orez din Ubud la templele de pe stânci ale Uluwatuluim, iată itinerarul perfect pentru Bali." },
  { id: 3, title: "Cum să Călătorești cu 30€ pe Zi în Europa", category: "Buget", date: "22 Apr 2026", readTime: "6 min", img: IMG.art3, excerpt: "Hosteluri selecte, mâncare de piață și transport inteligent — Europa nu trebuie să fie scumpă dacă știi câteva trucuri." },
  { id: 4, title: "Echipamentul Esențial pentru Trekking în Himalaya", category: "Gear", date: "14 Apr 2026", readTime: "10 min", img: IMG.art4, excerpt: "Lista completă de echipamente testată personal pe trasee la altitudine mare, cu recomandări pe categorii de buget." },
  { id: 5, title: "Aurora Boreală: Ghid de Fotografiere", category: "Fotografie", date: "5 Apr 2026", readTime: "9 min", img: IMG.art5, excerpt: "Setările corecte de cameră, locurile cele mai bune și sezonul optim pentru a captura cel mai mare spectacol al naturii." },
  { id: 6, title: "Nopți de Neuitat în Tokyo", category: "Urban", date: "28 Mar 2026", readTime: "7 min", img: IMG.art6, excerpt: "Neoane, izakaya-uri ascunse în alei întortocheate și tranziția magică spre zorii roz ai unui Tokyo neașteptat de liniștit." },
];

const gearItems = [
  { id: 1, name: "Osprey Atmos AG 65", category: "Rucsaci", price: "320 €", rating: 4.9, img: IMG.gear1, badge: "Top Pick", desc: "Sistemul AntiGravity face ca 65L să se simtă ca jumătate. Ideal pentru expediții de 5–14 zile." },
  { id: 2, name: "Salomon X Ultra 4 GTX", category: "Încălțăminte", price: "160 €", rating: 4.8, img: IMG.gear2, badge: "Best Value", desc: "Bocanci ușori cu membrană Gore-Tex waterproof. Testat pe trasee alpine umede și stâncoase." },
  { id: 3, name: "MSR Hubba Hubba NX 2", category: "Corturi", price: "480 €", rating: 4.7, img: IMG.gear3, badge: "Recomandat", desc: "Cort 4 sezoane de 1,72 kg. Rezistă la vânt puternic și ploaie torențială fără a sacrifica confortul." },
  { id: 4, name: "Therm-a-Rest NeoAir XLite", category: "Dormit", price: "190 €", rating: 4.8, img: IMG.gear4, badge: "Ultralight", desc: "Salteaua gonflabilă de referință la 340g. R-value 4,2 pentru nopți reci de munte până la –5°C." },
];

function Navbar({ activePage, setPage }: { activePage: Page; setPage: (p: Page) => void }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links: { label: string; page: Page }[] = [
    { label: "Acasă", page: "home" },
    { label: "Destinații", page: "destinations" },
    { label: "Despre noi", page: "about" },
    { label: "Echipament", page: "gear" },
    { label: "Contact", page: "contact" },
  ];

  const nav = (p: Page) => { setPage(p); setOpen(false); window.scrollTo(0, 0); };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-shadow"
      style={{ backgroundColor: TEAL, boxShadow: scrolled ? "0 2px 12px rgba(0,0,0,0.2)" : "none" }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <button
          onClick={() => nav("home")}
          className="flex items-center gap-2 cursor-pointer"
        >
          <Compass size={24} color={CORAL} />
          <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.5rem", color: "#fff", fontWeight: 700 }}>
            Wander<span style={{ color: CORAL }}>lust</span>
          </span>
        </button>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-1">
          {links.map(l => (
            <button
              key={l.page}
              onClick={() => nav(l.page)}
              className="px-4 py-2 rounded text-sm font-medium transition-colors"
              style={{
                color: activePage === l.page ? CORAL : "rgba(255,255,255,0.9)",
                fontFamily: "'Lato', sans-serif",
                background: activePage === l.page ? "rgba(255,255,255,0.12)" : "transparent",
              }}
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => nav("articles")}
            className="ml-3 flex items-center gap-1.5 px-4 py-2 rounded font-semibold text-sm transition-opacity hover:opacity-90"
            style={{ backgroundColor: CORAL, color: "#fff", fontFamily: "'Lato', sans-serif" }}
          >
            <BookOpen size={15} />
            Articole
          </button>
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-white" onClick={() => setOpen(o => !o)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-white/20 py-2" style={{ backgroundColor: TEAL }}>
          {links.map(l => (
            <button
              key={l.page}
              onClick={() => nav(l.page)}
              className="block w-full text-left px-6 py-3 text-sm"
              style={{ color: activePage === l.page ? CORAL : "rgba(255,255,255,0.9)", fontFamily: "'Lato', sans-serif" }}
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => nav("articles")}
            className="mx-4 mt-2 mb-1 flex items-center gap-2 px-4 py-2 rounded font-semibold text-sm"
            style={{ backgroundColor: CORAL, color: "#fff", fontFamily: "'Lato', sans-serif" }}
          >
            <BookOpen size={15} /> Articole
          </button>
        </div>
      )}
    </nav>
  );
}

function Footer({ setPage }: { setPage: (p: Page) => void }) {
  const nav = (p: Page) => { setPage(p); window.scrollTo(0, 0); };
  return (
    <footer className="text-white py-14 mt-auto" style={{ backgroundColor: "#1a1a1a", borderTop: `4px solid ${TEAL}` }}>
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <h5 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.4rem", marginBottom: "0.75rem" }}>
            <span style={{ color: TEAL }}>Wander</span><span style={{ color: CORAL }}>lust</span>
          </h5>
          <p className="text-sm text-gray-400 leading-relaxed mb-4">
            Un blog dedicat exploratorilor autentici. Ghiduri vizuale, bugete reale și recenzii de echipamente pentru aventura ta.
          </p>
          <div className="flex gap-4 text-xl">
            {[Instagram, Facebook, Youtube].map((Icon, i) => (
              <a key={i} href="#" className="transition-colors hover:text-white" style={{ color: TEAL }}><Icon size={20} /></a>
            ))}
          </div>
        </div>

        <div>
          <h6 className="uppercase text-xs font-bold tracking-widest text-white mb-4">Navigare</h6>
          <ul className="space-y-2">
            {(["home", "destinations", "articles", "gear"] as Page[]).map(p => (
              <li key={p}>
                <button onClick={() => nav(p)} className="text-sm text-gray-400 hover:text-white transition-colors">
                  {{ home: "Acasă", destinations: "Destinații", articles: "Articole", gear: "Echipament" }[p]}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h6 className="uppercase text-xs font-bold tracking-widest text-white mb-4">Contact direct</h6>
          <ul className="space-y-2 text-sm text-gray-400">
            <li className="flex items-center gap-2"><MapPin size={14} style={{ color: TEAL }} /> Chișinău, Moldova</li>
            <li className="flex items-center gap-2"><Mail size={14} style={{ color: TEAL }} /> contact@wanderlust.md</li>
            <li className="flex items-center gap-2"><Phone size={14} style={{ color: TEAL }} /> +373 60 000 000</li>
          </ul>
        </div>

        <div>
          <h6 className="uppercase text-xs font-bold tracking-widest text-white mb-4">Rămâi în contact</h6>
          <p className="text-sm text-gray-400 mb-3">Ghiduri lunare și reduceri la echipamente direct în inbox.</p>
          <form onSubmit={e => e.preventDefault()} className="flex gap-2">
            <input
              type="email"
              placeholder="Email-ul tău..."
              className="flex-1 px-3 py-2 rounded text-sm text-white bg-white/10 border border-white/20 focus:outline-none focus:border-white/50 placeholder-gray-500"
            />
            <button
              type="submit"
              className="px-3 py-2 rounded text-sm font-semibold text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: CORAL }}
            >
              <Send size={14} />
            </button>
          </form>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 mt-10 pt-6 border-t border-white/10 text-center text-sm text-gray-500">
        © 2026 <span style={{ color: TEAL }} className="font-semibold">Wanderlust</span>. Toate drepturile rezervate.
      </div>
    </footer>
  );
}

// ─── HOME PAGE ────────────────────────────────────────────────────────────────

function HeroCarousel({ setPage }: { setPage: (p: Page) => void }) {
  const [slide, setSlide] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const slides = [
    { img: IMG.hero1, title: "Descoperă Lumea", sub: "Ghiduri detaliate, trasee unice și sfaturi practice pentru exploratori.", cta: "Explorează Destinații", page: "destinations" as Page },
    { img: IMG.hero2, title: "Pregătește-ți Rucsacul", sub: "Recenzii obiective pentru cele mai rezistente echipamente outdoor.", cta: "Echipament Recomandat", page: "gear" as Page },
    { img: IMG.hero3, title: "Povești de la Orizont", sub: "Fiecare destinație ascunde o cultură nouă. Citește ultimele articole.", cta: "Citește Articolele", page: "articles" as Page },
  ];

  const reset = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setSlide(s => (s + 1) % slides.length), 5000);
  };

  useEffect(() => {
    reset();
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const go = (i: number) => { setSlide(i); reset(); };
  const prev = () => go((slide - 1 + slides.length) % slides.length);
  const next = () => go((slide + 1) % slides.length);

  return (
    <div className="relative overflow-hidden" style={{ height: "clamp(360px, 62vh, 680px)" }}>
      {slides.map((s, i) => (
        <div
          key={i}
          className="absolute inset-0 transition-opacity duration-1000"
          style={{ opacity: i === slide ? 1 : 0 }}
        >
          <img src={s.img} alt={s.title} className="w-full h-full object-cover" style={{ backgroundColor: "#374151" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.6) 100%)" }} />
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
            <h2
              className="text-white mb-3 max-w-2xl"
              style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem,5vw,3.2rem)", fontWeight: 700, textShadow: "0 2px 12px rgba(0,0,0,0.4)" }}
            >
              {s.title}
            </h2>
            <p className="text-white/90 mb-6 max-w-xl text-base md:text-lg" style={{ fontFamily: "'Lato', sans-serif", textShadow: "0 1px 6px rgba(0,0,0,0.4)" }}>
              {s.sub}
            </p>
            <button
              onClick={() => { setPage(s.page); window.scrollTo(0, 0); }}
              className="px-6 py-3 rounded font-bold text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: CORAL, fontFamily: "'Lato', sans-serif" }}
            >
              {s.cta}
            </button>
          </div>
        </div>
      ))}

      <button onClick={prev} className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2 transition-colors">
        <ChevronLeft size={20} />
      </button>
      <button onClick={next} className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2 transition-colors">
        <ChevronRight size={20} />
      </button>

      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => go(i)}
            className="rounded-full transition-all"
            style={{ width: i === slide ? 24 : 8, height: 8, backgroundColor: i === slide ? CORAL : "rgba(255,255,255,0.6)" }}
          />
        ))}
      </div>
    </div>
  );
}

function HomePage({ setPage }: { setPage: (p: Page) => void }) {
  return (
    <div>
      <HeroCarousel setPage={setPage} />

      {/* Welcome section */}
      <section className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-14 items-center">
        <div>
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-widest mb-4" style={{ backgroundColor: `${TEAL}18`, color: TEAL }}>
            Bine ai venit
          </span>
          <h1 className="mb-5" style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(1.8rem,3.5vw,2.6rem)", fontWeight: 700, lineHeight: 1.25 }}>
            Inspirație pentru<br />
            <em>următoarea ta călătorie</em>
          </h1>
          <p className="text-muted-foreground leading-relaxed mb-8 text-base" style={{ fontFamily: "'Lato', sans-serif" }}>
            Wanderlust este spațiul digital unde hărțile prind viață. Strângem impresii de pe drum, sfaturi despre cum să călătorești eficient și recenzii sincere de echipamente. Fiecare articol este scris după o experiență trăită personal.
          </p>
          <button
            onClick={() => { setPage("about"); window.scrollTo(0, 0); }}
            className="px-6 py-3 rounded border-2 font-semibold transition-colors hover:text-white"
            style={{ borderColor: TEAL, color: TEAL, fontFamily: "'Lato', sans-serif" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.backgroundColor = TEAL; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"; }}
          >
            Află mai multe despre noi
          </button>
        </div>
        <div className="relative">
          <img
            src={IMG.welcomeImg}
            alt="Explorare deșert"
            className="w-full rounded-2xl shadow-lg object-cover"
            style={{ height: 420, backgroundColor: "#9ca3af" }}
          />
          <div
            className="absolute -bottom-4 -left-4 px-5 py-4 rounded-xl shadow-xl text-white"
            style={{ backgroundColor: TEAL }}
          >
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.8rem", fontWeight: 700, lineHeight: 1 }}>120+</div>
            <div className="text-xs mt-1" style={{ fontFamily: "'Lato', sans-serif" }}>Destinații explorate</div>
          </div>
        </div>
      </section>

      {/* Featured destinations */}
      <section className="py-16" style={{ backgroundColor: "#f0f7f6" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-end justify-between mb-10">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest" style={{ color: TEAL }}>Descoperă</span>
              <h2 className="mt-1" style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 700 }}>Destinații Recomandate</h2>
            </div>
            <button
              onClick={() => { setPage("destinations"); window.scrollTo(0, 0); }}
              className="text-sm font-semibold hidden sm:flex items-center gap-1 hover:gap-2 transition-all"
              style={{ color: CORAL }}
            >
              Vezi toate <ChevronRight size={16} />
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
            {destinations.slice(0, 3).map(d => <DestCard key={d.id} d={d} />)}
          </div>
          <div className="sm:hidden mt-6 text-center">
            <button onClick={() => { setPage("destinations"); window.scrollTo(0, 0); }} className="text-sm font-semibold" style={{ color: CORAL }}>
              Vezi toate destinațiile →
            </button>
          </div>
        </div>
      </section>

      {/* Featured articles */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest" style={{ color: TEAL }}>Din blog</span>
            <h2 className="mt-1" style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 700 }}>Ultimele Articole</h2>
          </div>
          <button
            onClick={() => { setPage("articles"); window.scrollTo(0, 0); }}
            className="text-sm font-semibold hidden sm:flex items-center gap-1 hover:gap-2 transition-all"
            style={{ color: CORAL }}
          >
            Toate articolele <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {articles.slice(0, 3).map(a => <ArticleCard key={a.id} a={a} />)}
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-20 px-6" style={{ background: `linear-gradient(135deg, ${TEAL} 0%, #004d40 100%)` }}>
        <div className="max-w-2xl mx-auto text-center text-white">
          <h2 className="mb-4" style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 700 }}>
            Nu Rata Nicio Aventură
          </h2>
          <p className="mb-8 text-white/80" style={{ fontFamily: "'Lato', sans-serif" }}>
            Abonează-te la newsletter și primești lunar ghiduri de călătorie, itinerare detaliate și oferte exclusive la echipamente.
          </p>
          <form onSubmit={e => e.preventDefault()} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Adresa ta de email..."
              className="flex-1 px-4 py-3 rounded text-gray-800 text-sm focus:outline-none"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded font-bold text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: CORAL, fontFamily: "'Lato', sans-serif" }}
            >
              Mă Abonez
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}

// ─── SHARED COMPONENTS ────────────────────────────────────────────────────────

function DestCard({ d }: { d: typeof destinations[0] }) {
  return (
    <div className="bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow group">
      <div className="relative overflow-hidden" style={{ height: 220 }}>
        <img
          src={d.img}
          alt={d.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          style={{ backgroundColor: "#9ca3af" }}
        />
        <span className="absolute top-3 left-3 px-2 py-1 rounded text-xs font-bold text-white" style={{ backgroundColor: TEAL }}>
          {d.category}
        </span>
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between mb-1">
          <h3 className="font-bold text-base" style={{ fontFamily: "'Playfair Display', serif" }}>{d.name}</h3>
          <div className="flex items-center gap-1 text-xs font-semibold" style={{ color: CORAL }}>
            <Star size={12} fill={CORAL} /> {d.rating}
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
          <MapPin size={11} /> {d.country} · {d.days}
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
          {d.desc}
        </p>
      </div>
    </div>
  );
}

function ArticleCard({ a }: { a: typeof articles[0] }) {
  return (
    <div className="bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow group cursor-pointer">
      <div className="relative overflow-hidden" style={{ height: 200 }}>
        <img
          src={a.img}
          alt={a.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          style={{ backgroundColor: "#9ca3af" }}
        />
        <span className="absolute top-3 left-3 px-2 py-1 rounded text-xs font-bold text-white" style={{ backgroundColor: CORAL }}>
          {a.category}
        </span>
      </div>
      <div className="p-5">
        <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
          <span className="flex items-center gap-1"><Clock size={11} /> {a.readTime}</span>
          <span>{a.date}</span>
        </div>
        <h3 className="font-bold mb-2 leading-snug" style={{ fontFamily: "'Playfair Display', serif", fontSize: "1rem" }}>
          {a.title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
          {a.excerpt}
        </p>
        <div className="mt-4 flex items-center gap-1 text-xs font-bold" style={{ color: TEAL }}>
          Citește mai mult <ChevronRight size={13} />
        </div>
      </div>
    </div>
  );
}

function PageHeader({ title, subtitle, bg }: { title: string; subtitle?: string; bg?: string }) {
  return (
    <div
      className="pt-28 pb-14 px-6 text-center text-white"
      style={{ background: bg || `linear-gradient(135deg, ${TEAL} 0%, #00574f 100%)` }}
    >
      <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem,4vw,2.8rem)", fontWeight: 700 }}>{title}</h1>
      {subtitle && <p className="mt-3 text-white/80 max-w-xl mx-auto" style={{ fontFamily: "'Lato', sans-serif" }}>{subtitle}</p>}
    </div>
  );
}

// ─── DESTINATIONS PAGE ───────────────────────────────────────────────────────

function DestinationsPage() {
  const [filter, setFilter] = useState("Toate");
  const cats = ["Toate", "Plaje", "Trekking", "Natură", "Cultura", "Urban", "Aventură"];
  const filtered = filter === "Toate" ? destinations : destinations.filter(d => d.category === filter);

  return (
    <div>
      <PageHeader title="Destinații" subtitle="Locuri reale, experiențe trăite. Fiecare destinație a fost vizitată personal." />
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Filter bar */}
        <div className="flex flex-wrap gap-2 mb-10">
          {cats.map(c => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className="px-4 py-2 rounded-full text-sm font-semibold transition-colors"
              style={{
                backgroundColor: filter === c ? TEAL : "transparent",
                color: filter === c ? "#fff" : TEAL,
                border: `1.5px solid ${TEAL}`,
              }}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {filtered.map(d => <DestCard key={d.id} d={d} />)}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">Nicio destinație găsită în această categorie.</div>
        )}
      </div>
    </div>
  );
}

// ─── ARTICLES PAGE ───────────────────────────────────────────────────────────

function ArticlesPage() {
  const [filter, setFilter] = useState("Toate");
  const cats = ["Toate", "Trekking", "Asia", "Buget", "Gear", "Fotografie", "Urban"];
  const filtered = filter === "Toate" ? articles : articles.filter(a => a.category === filter);

  return (
    <div>
      <PageHeader title="Articole" subtitle="Povești din călătorii, sfaturi practice și ghiduri pas cu pas." />
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex flex-wrap gap-2 mb-10">
          {cats.map(c => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className="px-4 py-2 rounded-full text-sm font-semibold transition-colors"
              style={{
                backgroundColor: filter === c ? CORAL : "transparent",
                color: filter === c ? "#fff" : CORAL,
                border: `1.5px solid ${CORAL}`,
              }}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {filtered.map(a => <ArticleCard key={a.id} a={a} />)}
        </div>
      </div>
    </div>
  );
}

// ─── ABOUT PAGE ──────────────────────────────────────────────────────────────

function AboutPage({ setPage }: { setPage: (p: Page) => void }) {
  const stats = [
    { value: "120+", label: "Destinații vizitate" },
    { value: "6", label: "Continente explorate" },
    { value: "48", label: "Articole publicate" },
    { value: "12k", label: "Cititori lunari" },
  ];

  return (
    <div>
      <PageHeader title="Despre mine" subtitle="Cine se ascunde în spatele jurnalului de călătorii Wanderlust" />

      {/* Bio section */}
      <section className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <img
            src={IMG.aboutPortrait}
            alt="Autoarea blogului Wanderlust"
            className="w-full rounded-2xl shadow-lg object-cover"
            style={{ height: 500, backgroundColor: "#9ca3af" }}
          />
          <div
            className="absolute -bottom-5 -right-5 p-5 rounded-2xl shadow-xl text-white text-center"
            style={{ backgroundColor: CORAL }}
          >
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 700, lineHeight: 1 }}>2019</div>
            <div className="text-xs mt-1" style={{ fontFamily: "'Lato', sans-serif" }}>Primul articol</div>
          </div>
        </div>

        <div>
          <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4" style={{ backgroundColor: `${TEAL}18`, color: TEAL }}>
            Povestea mea
          </span>
          <h2 className="mb-5" style={{ fontFamily: "'Playfair Display', serif", fontSize: "2.2rem", fontWeight: 700, lineHeight: 1.25 }}>
            O moldoveancă <em>cu rucsacul în spinare</em>
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-5" style={{ fontFamily: "'Lato', sans-serif" }}>
            Mă numesc <strong>Elena Moraru</strong> și am plecat prima dată singură pe munte la 22 de ani, fără experiență și cu echipament nepotrivit. Am căzut de două ori, m-am rătăcit o oră și am ajuns la cabană cu 10 minute înainte de furtună. A fost cel mai bun lucru care mi s-a întâmplat.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-8" style={{ fontFamily: "'Lato', sans-serif" }}>
            De atunci, am traversat 6 continente, am dormit în corturi la –10°C în Islanda, am înotat cu rechini de recif în Maldive și am mâncat insecte prăjite pe o stradă din Bangkok. Wanderlust este jurnalul acestor aventuri — scris cinstit, fără filtre și cu bugetele reale afișate.
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => { setPage("contact"); window.scrollTo(0, 0); }}
              className="px-5 py-3 rounded font-semibold text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: TEAL, fontFamily: "'Lato', sans-serif" }}
            >
              Scrie-mi
            </button>
            <button
              onClick={() => { setPage("articles"); window.scrollTo(0, 0); }}
              className="px-5 py-3 rounded font-semibold transition-colors border-2"
              style={{ borderColor: TEAL, color: TEAL, fontFamily: "'Lato', sans-serif" }}
            >
              Citește articolele
            </button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 px-6" style={{ backgroundColor: "#f0f7f6" }}>
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map(s => (
            <div key={s.label} className="text-center p-6 bg-card rounded-2xl shadow-sm">
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "2.2rem", fontWeight: 700, color: TEAL }}>{s.value}</div>
              <div className="text-sm text-muted-foreground mt-1" style={{ fontFamily: "'Lato', sans-serif" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Journey image */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="mb-5" style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.9rem", fontWeight: 700 }}>
              De ce scriu despre <em>echipament</em>?
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-5" style={{ fontFamily: "'Lato', sans-serif" }}>
              Am pierdut timp și bani cumpărând echipamente greșite la prețuri mari. Bocanci care mi-au rupt picioarele în prima zi, un rucsac care s-a rupt la al doilea traseu și un cort care nu a rezistat primei ploi serioase.
            </p>
            <p className="text-muted-foreground leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
              Acum testez fiecare produs cel puțin 30 de zile pe teren înainte de a scrie o recenzie. Fără reclame plătite, fără link-uri afiliate ascunse. Doar opinia mea sinceră după experiență directă.
            </p>
          </div>
          <img
            src={IMG.aboutHero}
            alt="Trekking în natură"
            className="w-full rounded-2xl shadow-md object-cover"
            style={{ height: 380, backgroundColor: "#9ca3af" }}
          />
        </div>
      </section>
    </div>
  );
}

// ─── GEAR PAGE ───────────────────────────────────────────────────────────────

function GearPage() {
  const [tab, setTab] = useState("Toate");
  const cats = ["Toate", "Rucsaci", "Încălțăminte", "Corturi", "Dormit"];
  const filtered = tab === "Toate" ? gearItems : gearItems.filter(g => g.category === tab);

  return (
    <div>
      <PageHeader title="Echipament Recomandat" subtitle="Produse testate personal pe teren. Recenzii 100% independente, fără sponsorizări." />

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Category tabs */}
        <div className="flex flex-wrap gap-2 mb-12 border-b border-border pb-6">
          {cats.map(c => (
            <button
              key={c}
              onClick={() => setTab(c)}
              className="px-5 py-2 rounded-full text-sm font-semibold transition-all"
              style={{
                backgroundColor: tab === c ? TEAL : "transparent",
                color: tab === c ? "#fff" : "#555",
                border: `1.5px solid ${tab === c ? TEAL : "#ccc"}`,
              }}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-7">
          {filtered.map(g => (
            <div key={g.id} className="bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow group">
              <div className="relative" style={{ height: 200 }}>
                <img
                  src={g.img}
                  alt={g.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  style={{ backgroundColor: "#9ca3af" }}
                />
                <span className="absolute top-3 right-3 px-2 py-1 rounded text-xs font-bold text-white" style={{ backgroundColor: CORAL }}>
                  {g.badge}
                </span>
              </div>
              <div className="p-5">
                <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                  <Tag size={11} /> {g.category}
                </div>
                <h3 className="font-bold text-sm mb-1" style={{ fontFamily: "'Playfair Display', serif" }}>{g.name}</h3>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-bold text-base" style={{ color: TEAL }}>{g.price}</span>
                  <div className="flex items-center gap-1 text-xs" style={{ color: CORAL }}>
                    <Star size={11} fill={CORAL} /> {g.rating}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>{g.desc}</p>
                <button
                  className="mt-4 w-full flex items-center justify-center gap-2 py-2 rounded text-xs font-bold text-white transition-opacity hover:opacity-90"
                  style={{ backgroundColor: TEAL }}
                >
                  <ExternalLink size={12} /> Vezi Recenzia
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Gear info banner */}
        <div className="mt-16 rounded-2xl p-8 md:p-12 text-white" style={{ background: `linear-gradient(135deg, ${TEAL} 0%, #004d40 100%)` }}>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.6rem", fontWeight: 700, marginBottom: "0.75rem" }}>
                Cum aleg echipamentul?
              </h3>
              <p className="text-white/80 leading-relaxed" style={{ fontFamily: "'Lato', sans-serif" }}>
                Testez fiecare produs minimum 30 de zile pe trasee reale. Nu accept sponsorizări și nu folosesc link-uri afiliate. Recenziile mele reflectă strict experiența personală.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {["30+ zile testare", "Fără sponsorizări", "Preț vs. calitate", "Opinie sinceră"].map(l => (
                <div key={l} className="flex items-center gap-2 text-sm text-white/90">
                  <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: CORAL }} />
                  {l}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── CONTACT PAGE ─────────────────────────────────────────────────────────────

function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div>
      <PageHeader title="Contact" subtitle="Ai o întrebare, o propunere de colaborare sau vrei să îmi povestești aventura ta?" />

      <div className="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-5 gap-16">
        {/* Info */}
        <div className="md:col-span-2">
          <h2 className="mb-6" style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.6rem", fontWeight: 700 }}>
            Hai să <em>vorbim</em>
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-8" style={{ fontFamily: "'Lato', sans-serif" }}>
            Răspund la toate mesajele în maxim 48 de ore. Sunt deschisă la colaborări editoriale, recenzii de echipamente și proiecte travel.
          </p>

          <div className="space-y-5">
            {[
              { Icon: MapPin, label: "Locație", value: "Chișinău, Moldova" },
              { Icon: Mail, label: "Email", value: "contact@wanderlust.md" },
              { Icon: Phone, label: "Telefon", value: "+373 60 000 000" },
            ].map(({ Icon, label, value }) => (
              <div key={label} className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${TEAL}18` }}>
                  <Icon size={18} style={{ color: TEAL }} />
                </div>
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{label}</div>
                  <div className="text-sm font-medium mt-0.5" style={{ fontFamily: "'Lato', sans-serif" }}>{value}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10">
            <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Social Media</div>
            <div className="flex gap-3">
              {[Instagram, Facebook, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-xl flex items-center justify-center transition-colors"
                  style={{ backgroundColor: `${TEAL}18`, color: TEAL }}
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="md:col-span-3">
          {sent ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-16 rounded-2xl" style={{ backgroundColor: "#f0f7f6" }}>
              <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: TEAL }}>
                <Send size={24} color="#fff" />
              </div>
              <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.5rem", fontWeight: 700, marginBottom: "0.5rem" }}>
                Mesaj trimis!
              </h3>
              <p className="text-muted-foreground" style={{ fontFamily: "'Lato', sans-serif" }}>
                Îți mulțumesc pentru mesaj. Voi reveni în maxim 48 de ore.
              </p>
              <button
                onClick={() => setSent(false)}
                className="mt-6 px-5 py-2 rounded font-semibold text-white"
                style={{ backgroundColor: TEAL }}
              >
                Trimite alt mesaj
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-card rounded-2xl shadow-sm p-8 space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
                    <User size={11} className="inline mr-1" />Nume
                  </label>
                  <input
                    required
                    type="text"
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Numele tău"
                    className="w-full px-4 py-3 rounded-lg border border-border text-sm focus:outline-none focus:ring-2 transition-shadow"
                    style={{ "--tw-ring-color": TEAL } as React.CSSProperties}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
                    <Mail size={11} className="inline mr-1" />Email
                  </label>
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    placeholder="email@exemplu.com"
                    className="w-full px-4 py-3 rounded-lg border border-border text-sm focus:outline-none focus:ring-2 transition-shadow"
                    style={{ "--tw-ring-color": TEAL } as React.CSSProperties}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
                  <Tag size={11} className="inline mr-1" />Subiect
                </label>
                <input
                  required
                  type="text"
                  value={form.subject}
                  onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                  placeholder="Despre ce vrei să vorbim?"
                  className="w-full px-4 py-3 rounded-lg border border-border text-sm focus:outline-none focus:ring-2 transition-shadow"
                  style={{ "--tw-ring-color": TEAL } as React.CSSProperties}
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
                  <MessageSquare size={11} className="inline mr-1" />Mesaj
                </label>
                <textarea
                  required
                  rows={5}
                  value={form.message}
                  onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                  placeholder="Scrie mesajul tău aici..."
                  className="w-full px-4 py-3 rounded-lg border border-border text-sm focus:outline-none focus:ring-2 transition-shadow resize-none"
                  style={{ "--tw-ring-color": TEAL } as React.CSSProperties}
                />
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3 rounded-lg font-bold text-white transition-opacity hover:opacity-90"
                style={{ backgroundColor: TEAL, fontFamily: "'Lato', sans-serif" }}
              >
                <Send size={16} />
                Trimite Mesajul
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState<Page>("home");
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background" style={{ fontFamily: "'Lato', sans-serif" }}>
      <Navbar activePage={page} setPage={setPage} />

      <main className="flex-1 pt-16">
        {page === "home" && <HomePage setPage={setPage} />}
        {page === "destinations" && <DestinationsPage />}
        {page === "articles" && <ArticlesPage />}
        {page === "about" && <AboutPage setPage={setPage} />}
        {page === "gear" && <GearPage />}
        {page === "contact" && <ContactPage />}
      </main>

      <Footer setPage={setPage} />

      {/* Back to top */}
      {showTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 w-11 h-11 rounded-full text-white shadow-lg flex items-center justify-center transition-opacity hover:opacity-90 z-50"
          style={{ backgroundColor: CORAL }}
          aria-label="Înapoi sus"
        >
          <ArrowUp size={18} />
        </button>
      )}
    </div>
  );
}
